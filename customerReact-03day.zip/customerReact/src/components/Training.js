import React, { Component } from 'react';
import Menu from './Menu';
import {TimerF} from './Timer';
import ReducerEx from './ReducerExample';
import ContextEx from './ContextApp';
import {ToggleApp} from './ToggleApp';

function  Training () {
      return (
         <div>
              <Menu/>
            <h2>Training</h2>
            <TimerF name="App 22"  email="rama@abc.com"/>
            <ReducerEx/>
         </div>
      );
}
export default Training;