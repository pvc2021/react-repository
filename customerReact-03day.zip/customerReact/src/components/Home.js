import React, { Component } from 'react';
import Menu from './Menu';
import {getCustomers} from '../service/CustomerService'

class Home extends Component {
   render() {
      return (
         <div>
            <Menu/>
            <h2>Home</h2>
            <p>We have {getCustomers().length} customer records on our system.</p>
         </div>
      );
   }
}
export default Home;