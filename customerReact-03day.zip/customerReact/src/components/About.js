import React, { Component } from 'react';
import Menu from './Menu';
import {TimerF} from './Timer';
import ReducerEx from './ReducerExample';
import ContextEx from './ContextApp';
import {ToggleApp} from './ToggleApp';

function  About () {
      return (
         <div>
              <Menu/>
            <h2>About</h2>
            <TimerF name="App 22"  email="rama@abc.com"/>
            <ReducerEx/>
            <ContextEx/>
            <ToggleApp/>
         </div>
      );
}
export default About;