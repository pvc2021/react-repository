import React from 'react';
import ReactDOM from 'react-dom';
import Menu from './Menu';
import {getCustomers,addCustomer,updateCustomer,deleteCustomer} from '../service/CustomerServiceRest';

class CustomerApp extends React.Component {
  constructor(props) {
    super(props);
    //internal varibale
    this.state = { items: [], 
      id:0,
      name: '',
      email: '',
      phone: '',
      address: '',
      bLabel: 'Add'
     };
  }
  async syncCustomer(){
    var list = await getCustomers();
    this.setState({items:list});
  }
  componentDidMount(){
    this.syncCustomer();
  }
  render() {
    return (
      <div>
        <Menu/>
        <h3>Customers</h3>
        <form onSubmit={this.handleSubmit}>
          <input placeholder="Name" name="name"
            onChange={this.handleChange}
            value={this.state.name}
          /><br/><br/>
          <input placeholder="Email"  name="email"
            onChange={this.handleChange}
            value={this.state.email}
          /><br/><br/>
          <input placeholder="Phone"  name="phone"
            onChange={this.handleChange}
            value={this.state.phone}
          /><br/><br/>
          <input placeholder="Address"  name="address"
            onChange={this.handleChange}
            value={this.state.address}
          /><br/><br/>
          <button>{this.state.bLabel}</button> <br/><br/>
        </form>
        <TodoList items={this.state.items} 
        doDelete={this.handleDelete} 
        doEdit={this.handleEdit} 
        />
      </div>
    );
  }

  handleEdit = (id) => {
    console.log("edit id::"+id);
    let tempArray = this.state.items.filter((item)=>(item.id == id));
    
    if(tempArray.length > 0){
      this.setState(tempArray[0]);
      this.setState({bLabel:'Update'});
    }
  }

  handleDelete = async (id) => {
    await deleteCustomer(id);
    this.syncCustomer();
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleSubmit = async (e) => {
    console.log("name:",this.state.name);
    e.preventDefault();
    if (!this.state.name.length) {
      return;
    }
    const newItem = {
      name: this.state.name,
      email: this.state.email,
      phone: this.state.phone,
      address: this.state.address,
      id: Date.now()
    };
    if(this.state.id != 0){ //edit
      newItem.id = this.state.id;
      await updateCustomer(newItem);
      
      this.setState(prevState => ({
        bLabel:'Add',
        id:0,
        name: '',
        email:'',
        phone:'',
        address:'',
      }));
      this.syncCustomer()
    }else{ //add
      await addCustomer(newItem);
      this.setState(prevState => ({
        bLabel:'Add',
        id:0,
        name: '',
        email:'',
        phone:'',
        address:'',
      }));
      this.syncCustomer();
    }
  }
}

class TodoList extends React.Component {
  render() {
    return (
      <div>
          <ol className="collection collection-container">
            <li className="item item-container">
              <div className="attribute" data-name="No">No</div>
              <div className="attribute-container information">
                <div className="attribute-container name-email">
                  <div className="attribute" data-name="Name">Name</div>
                  <div className="attribute" data-name="Email">Email</div>
                </div>
                <div className="attribute-container phone-add">
                  <div className="attribute" data-name="Phone">Phone</div>
                  <div className="attribute" data-name="Address">Address</div>
                </div>
              </div>
              <div className="attribute-container edit-del">
                <div className="attribute" data-name="Edit">Edit</div>
                <div className="attribute" data-name="Delete">Delete</div>
              </div>
            </li>
            {this.props.items.map((item)=>{
                        return(<li key={item.id} className="item item-container">
                          <div className="attribute" data-name="No">{item.id}</div>
                          <div className="attribute-container information">
                            <div className="attribute-container name-email">
                              <div className="attribute" data-name="Name" id={'name'+item.id}>{item.name}</div>
                              <div className="attribute" data-name="Email">{item.email}</div>
                            </div>
                            <div className="attribute-container phone-add">
                              <div className="attribute" data-name="Phone">{item.phone}</div>
                              <div className="attribute" data-name="Address">{item.address}</div>
                            </div>
                          </div>
                          <div className="attribute-container edit-del">
                            <div className="attribute" data-name="Edit"><button  style={{"maxWidth": "60px", "marginTop": "2.5px"}} onClick={()=>this.props.doEdit(item.id)} >Edit</button></div>
                            <div className="attribute" data-name="Delete"><button style={{"maxWidth": "60px", "marginTop": "2.5px"}} onClick={()=>this.props.doDelete(item.id)}>Delete</button></div>
                          </div>
                        </li>)
            })}

          </ol>
      </div>
    );
  }
}

export default CustomerApp;