import React from 'react';
import ReactDOM from 'react-dom';
import Menu from './Menu';

class CustomerApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = { items: [
      {id:1,name:'Vivek',email:'vivek@pyther.com',address:'India', phone:'982423322'},
      {id:2,name:'Joshua',email:'josh@pyther.com',address:'USA', phone:'746454654'},
    ], 
      id:0,
      name: '',
      email: '',
      phone: '',
      address: '',
      bLabel: 'Add'
     };
  }
  handleEdit = (id) => {
    console.log("edit id::"+id);
    let tempArray = this.state.items.filter((item)=>(item.id == id));
    
    if(tempArray.length > 0){
      this.setState(tempArray[0]);
      this.setState({bLabel:'Update'});
    }
  }

  handleDelete = (id) => {
    console.log("id::"+id);
    let tempArray = this.state.items.filter((item)=>(item.id != id));
    this.setState({ items:tempArray });
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleSubmit = (e) => {
    console.log("name:",this.state.name);
    e.preventDefault();
    if (!this.state.name.length) {
      return;
    }
    const newItem = {
      name: this.state.name,
      email: this.state.email,
      phone: this.state.phone,
      address: this.state.address,
      id: Date.now()
    };
    if(this.state.id != 0){ //edit
      newItem.id = this.state.id;
      let tempItems = this.state.items.map((item)=>{
        if(item.id == this.state.id){
          return newItem;
        }else{
          return item;
        }
      })
      this.setState(prevState => ({
        items: tempItems,
        bLabel:'Add',
        id:0,
        name: '',
        email:'',
        phone:'',
        address:'',
      }));
    }else{ //add
      this.setState(prevState => ({
        items: prevState.items.concat(newItem),
        bLabel:'Add',
        id:0,
        name: '',
        email:'',
        phone:'',
        address:'',
      }));
    }
    console.log("newItem:",newItem);
  }
  render() {
    return (
      <div>
        <Menu/>
        <form onSubmit={this.handleSubmit}>
          <input placeholder="Name" name="name"
            onChange={this.handleChange}
            value={this.state.name}
          /><br/><br/>
          <input placeholder="Email"  name="email"
            onChange={this.handleChange}
            value={this.state.email}
          /><br/><br/>
          <input placeholder="Phone"  name="phone"
            onChange={this.handleChange}
            value={this.state.phone}
          /><br/><br/>
          <input placeholder="Address"  name="address"
            onChange={this.handleChange}
            value={this.state.address}
          /><br/><br/>
          <button>{this.state.bLabel}</button> <br/><br/>
        </form>
        <CustomersList items={this.state.items} 
        doDelete={this.handleDelete} 
        doEdit={this.handleEdit} 
        />
      </div>
    );
  }
}

function CustomersList ({items,doDelete,doEdit}) {
   // function TodoList (props) {
    return (
      <div>
          <ol className="collection collection-container">
            <li className="item item-container">
              <div className="attribute" data-name="No">No</div>
              <div className="attribute-container information">
                <div className="attribute-container name-email">
                  <div className="attribute" data-name="Name">Name</div>
                  <div className="attribute" data-name="Email">Email</div>
                </div>
                <div className="attribute-container phone-add">
                  <div className="attribute" data-name="Phone">Phone</div>
                  <div className="attribute" data-name="Address">Address</div>
                </div>
              </div>
              <div className="attribute-container edit-del">
                <div className="attribute" data-name="Edit">Edit</div>
                <div className="attribute" data-name="Delete">Delete</div>
              </div>
            </li>
            {items.map((item)=>{
                        return(<li key={item.id} className="item item-container">
                          <div className="attribute" data-name="No">{item.id}</div>
                          <div className="attribute-container information">
                            <div className="attribute-container name-email">
                              <div className="attribute" data-name="Name">{item.name}</div>
                              <div className="attribute" data-name="Email">{item.email}</div>
                            </div>
                            <div className="attribute-container phone-add">
                              <div className="attribute" data-name="Phone">{item.phone}</div>
                              <div className="attribute" data-name="Address">{item.address}</div>
                            </div>
                          </div>
                          <div className="attribute-container edit-del">
                            <div className="attribute" data-name="Edit"><button  
                            style={{"maxWidth": "60px", "marginTop": "2.5px"}} 
                            onClick={()=>doEdit(item.id)} >Edit</button></div>
                            <div className="attribute" data-name="Delete"><button 
                            style={{"maxWidth": "60px", "marginTop": "2.5px"}} 
                            onClick={()=>doDelete(item.id)}>Delete</button></div>
                          </div>
                        </li>)
            })}

          </ol>
      </div>
    );
  }

export default CustomerApp;