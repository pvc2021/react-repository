import React, { Component } from 'react';

class Login extends Component {
   render() {
      return (
         <div>
            <h2>Login</h2>
            <form>
               <input ></input><br/><br/>
               <input ></input><br/><br/>
               <input type="button" onClick={()=>{window.location="/home"}} value="Login"></input><br/><br/>
            </form>
         </div>
      );
   }
}
export default Login;