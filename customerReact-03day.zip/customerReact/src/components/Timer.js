import React, {useEffect, useState} from 'react';

export function SimpleF({name}) {
  return (
    <div>
      <h3>Hello {name} </h3>
    </div>
  );
}

export function TimerF({name,email}) {

  const [count,setCount] = useState(0); //

  // ES6
  // [a,b] = [5,7];
  const [intervalVal,setIntervalVal] = useState(0); //

  //no lifecycle methids in functional components
  // useEffect(func, [])
  useEffect(()=>{  
    // mount
    console.log(">> useEffect call every time if there in any change or for any new call");
    startTimer(); //componentDidMount
    return(stopTimer)  // unmount 
  },[]);

  var tick = () => {
    setCount(prevVal => (prevVal + 1));
  }

  var resetTimer = () => {
    setCount(0);
  }

  var stopTimer = () => {
    clearInterval(intervalVal);
  }
  var startTimer = () => {
    var interval = setInterval(() => tick(), 1000);
    setIntervalVal(interval);
  }
  return (
    <div>
      Functional Seconds: {count} <br/><br/>
      <h4>{name} email  {email}</h4>
      <button onClick={stopTimer}> Stop</button>&nbsp;
      <button onClick={resetTimer}> Reset to 0</button>&nbsp;
      <button onClick={startTimer} >Start</button>
    </div>
  );
} 

export class TimerC extends React.Component {
  //life cycle methods are here ONLY in class component
  constructor(props) {
    super(props);
    console.log(">>constructor");
    this.state = { seconds: 0 };
  }

  tick() {
    this.state.seconds =   (this.state.seconds +1);
    //this.setState({});
    this.forceUpdate();
    /*
    this.setState(prevState => ({
      seconds: prevState.seconds + 1
    }));
    */
  }

  resetTimer = () => {
    this.setState({seconds: 0});
  }

  stopTimer = () => {
    clearInterval(this.interval);
  }


  startTimer = () => {
    this.interval = setInterval(() => this.tick(), 1000);
  }

  //componentWillMount
  componentDidMount() {
    console.log(">>componentDidMount");
    this.startTimer();
  }

  componentWillUnmount() {
    console.log(">>componentWillUnmount");
    this.stopTimer();
  }

  render() {
    return (
      <div>
        Class Seconds: {this.state.seconds} <br/><br/>
        <button onClick={this.stopTimer}> Stop</button>&nbsp;
        <button onClick={this.resetTimer}> Reset to 0</button>&nbsp;
        <button onClick={this.startTimer} >Start</button>
      </div>
    );
  }
}
