import React, {useState} from 'react';
function toggle(isShow){
    if(isShow){
        return (
            <h3>
                I am here. Toggle
            </h3>
        )
    }
}

export function ToggleApp() {  //name,email is state
    //var [ a = 1, b = 2, c = 3, d ] = list
    const [isShow,setShow] = useState(false); //count is state
  
    let onButtonClick = () =>{
        setShow((lastval)=>(!lastval));
    }
    console.log("ToggleApp .. rendered "+isShow);
    return (

      <div>
          <h4>Show Hide App </h4>
          <button onClick={onButtonClick}>Show/Hide</button>
          {toggle(isShow)}
      </div>
    );
  }