import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import {TimerF, TimerC,SimpleF} from './components/Timer';
import {ToggleApp} from './components/ToggleApp';
import CustomerApp from './components/CustomerAppC';
import Home from './components/Home';
import Login from './components/Login';
import About from './components/About';
import Training from './components/Training';

function App() {
  return (
    <Router>
    <div style={{marginLeft:'5px'}}>
       <h2>Customer App</h2>
       <hr />
       <Switch>
          <Route exact path='/' component={Login} />
          <Route exact path='/home' component={Home} />
          <Route exact path='/customer' component={CustomerApp} />
          <Route exact path='/about' component={About} />
          <Route exact path='/training' component={Training} />
          <Route exact path='/login' component={Login} />
       </Switch>
    </div>
 </Router>
  );
}
export default App;