//import the redux
let redux=require("redux");


//create action
const Buy_Book='Buy_Book';


const action={
    type:Buy_Book,
    info:'Buy Book from store reduces the nunmberOfBooks by 1'
}


//initialState
const initialState={
    numberOfBooks:10
}


//dispatcher
function buyBook(){
    return action;
}





//Reducer tkaes 2 params : (prevState,action)=> newState

const Reducer=(state=initialState,action)=>{

    switch(action.type){

        case 'Buy_Book':{
            return {...state,numberOfBooks:state.numberOfBooks-1}
        }

        case 'Add_Book':{
            return {...state,numberOfBooks:state.numberOfBooks+1}
        }


        default: return state;

    }//switch
}//Reducer



//create store
const bookStore=redux.createStore(Reducer);
console.log("Initial State i.e Number of books: ",bookStore.getState());
const unsubscribe=bookStore.subscribe(()=>{console.log("Updated State :Available  Number of Books :",bookStore.getState())});



bookStore.dispatch(buyBook());
bookStore.dispatch(buyBook());
bookStore.dispatch(buyBook());
unsubscribe();
bookStore.dispatch(buyBook());
bookStore.dispatch(buyBook());





