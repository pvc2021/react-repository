import logo from './logo.svg';
import './App.css';
import Greet from "./components/Greet"

import {BrowserRouter as Router,Route,Link} from "react-router-dom"
import Colors from './components/Colors'
import Home from './components/Home'
import ReactBasics from './components/ReactBasics'
import Catalog from './components/Catalog';

function App() {
  return (

    <Router>
    <div className="App">
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">

    <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><Link   to="/home">Home</Link></li>
    <li ><Link to="/basics">React Basics</Link></li>
    <li ><Link to="/colors">Colors</Link></li>
    <li ><Link to="/catalog">Catalog</Link></li>
    
    
    

      <li class="dropdown">  <Link to="/casestudy">CaseStudy<span class="caret"></span></Link>   
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>
      <li><a href="#">Page 2</a></li>
      <li><a href="#">Page 3</a></li>
    </ul>
  </div>
</nav>
  

<div>
 
<Route  exact path="/"   component={Home}/>
<Route  path="/home"   component={Home}/>
<Route   path="/basics"   component={ReactBasics}/>
<Route   path="/colors"   component={Colors}/>
<Route   path="/catalog"   component={Catalog}/>
 </div>





    </div>
    </Router>
  );
}

export default App;
