import logo from './logo.svg';
import './App.css';

import User from "./components/User"


import {BrowserRouter as Router,Route,Link} from "react-router-dom"
import { Provider } from 'react-redux'
import Colors from './components/Colors'
import Home from './components/Home'
import ReactBasics from './components/ReactBasics'
import Catalog from './components/Catalog';
import Counter from './components/Counter';
import Post from './components/Post';
import UsersList from './components/UsersList';
import UsersTable from './components/UsersTable';
import StateLift from './components/StateLift';
import Context from './components/Context';
import ReactForm from './components/ReactForm';
import Hoc from './components/Hoc';
import ListProducts from './components/ListProducts';
import AddProduct from './components/AddProduct';
import productStore from './components/store/productStore';
import Hooks from './components/Hooks';

function App() {
  return (
<Provider  store={productStore}>
    <Router>
    <div className="App">
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">

    <a className="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><Link   to="/home">Home</Link></li>
    <li ><Link to="/basics">React Basics</Link></li>
    <li ><Link to="/colors">Colors</Link></li>
    <li ><Link to="/catalog">Catalog</Link></li>
    <li ><Link to="/counter">Counter</Link></li>
    <li ><Link to="/statelift">State Lift</Link></li>
    
    
    
    
    

      <li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">CaseStudy <span class="caret"></span> </a>   
        <ul class="dropdown-menu">
        <li ><Link to="/user-list">Users List</Link></li>
        <li ><Link to="/user-table">Users Table</Link></li>
        
        <li ><Link to="/posts">Posts</Link></li>
        <li ><Link to="/comments">Comments</Link></li>
        <li ><Link to="/todos">Todos</Link></li>
        <li ><Link to="/albums">Albums</Link></li>
        <li ><Link to="/photos">Photos</Link></li>
        
        
        
                 
         
         
          </ul>
      </li>
      <li><Link to="/context">Context API</Link></li>
      <li><Link to="/forms">React Forms</Link></li>
      <li><Link to="/hoc">High Order Componet</Link></li>
      <li ><Link to="/list-products">List Product</Link></li>
      <li ><Link to="/add-product">Add Product</Link></li>
      <li ><Link to="/hooks">Hooks Demo</Link></li>
                  

    </ul>
  </div>
</nav>
  

<div class="container">
 
<Route  exact path="/"   component={Home}/>
<Route  path="/home"   component={Home}/>
<Route   path="/basics"   component={ReactBasics}/>
<Route   path="/colors"   component={Colors}/>
<Route   path="/catalog"   component={Catalog}/>
<Route   path="/counter"   component={Counter}/>
<Route   path="/posts"   component={Post}/>
<Route   path="/user/:userId"   component={User}/>
<Route   path="/user-list"   component={UsersList}/>
<Route   path="/user-table"   component={UsersTable}/>
<Route   path="/statelift"   component={StateLift}/>
<Route   path="/context"   component={Context}/>
<Route   path="/forms"   component={ReactForm}/>
<Route   path="/hoc"   component={Hoc}/>
<Route   path="/list-products"   component={ListProducts}/>
<Route   path="/add-product"   component={AddProduct}/>
<Route   path="/hooks"   component={Hooks}/>



</div>


    </div>
    </Router>
    </Provider>
  );
}

export default App;
