import axios from 'axios';
import React, { Component } from 'react';



/*
https://jsonplaceholder.typicode.com/users
https://jsonplaceholder.typicode.com/users/1           =RouteParam  GET,PUT,DELET,PATCH
https://jsonplaceholder.typicode.com/posts/1           =RouteParam  
https://jsonplaceholder.typicode.com/posts?userId=1    =QueryParam GET






*/
class Post extends Component {


  state={
    title:'All Posts',
    userId:0,
    posts:[]
  }

constructor(props){
    super(props);
    console.log("=============PostComponent creeated================");
}


componentDidMount(){

const query=new URLSearchParams(this.props.location.search);
console.log("===============",query);

let userId=query.get("userId");


if(userId)
{
    console.log("===Getting the posts from  :https://jsonplaceholder.typicode.com/posts?userId="+userId);


    axios.get(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`)
         .then(response=>{
             this.setState({posts:response.data})
         }) 
    
}
else
{
    console.log("===Getting the posts from  :https://jsonplaceholder.typicode.com/posts====");


    axios.get('https://jsonplaceholder.typicode.com/posts')
         .then(response=>{
             this.setState({posts:response.data})
         }) 
    

}


}


componentWillUnmount(){
    console.log("=============PostComponent destroyed================");  
}




    render() {
        return (
            <div class="jumbotron">

                       


                <h2>  {this.state.title} </h2>
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>USER ID</th>
                            <th>POST ID</th>
                            <th>TITLE</th>
                            <th>BODY</th>
                            <th>VIEW COMMENTS</th>
                          </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.posts.map(p=>{
                           return <tr key={p.id}>
                              <td>{p.userId}</td>
                              <td>{p.id}</td>
                              <td>{p.title}</td>
                              <td>{p.body}</td>
                              <td> <input type="button" value="VIEW COMMENTS" class="btn btn-info" />  </td>
                          </tr>
                          })


                    }
                   </tbody>
                </table>



            </div>
        );
    }
}

export default Post;