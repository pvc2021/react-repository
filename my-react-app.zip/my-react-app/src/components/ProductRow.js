import axios from 'axios';
import React, { Component } from 'react';
import {connect} from 'react-redux';

class ProductRow extends Component {

constructor(props){
    super(props);
    console.log("==========Product Row created==============="); 
}


deleteProductById=()=>{

    axios.delete("http://localhost:3001/products/"+this.props.product.id)
    .then(response=>{
        if(response.status===200){
        this.props.dispatch({
            type:'DELETE_PRODUCT',
            id:this.props.product.id
        })
    }}).catch(error=>{
        console.log(error);
    });
}



    render() {

        return (
          <tr>
            <td>{this.props.product.id}</td>
            <td>{this.props.product.name}</td>
            <td>{this.props.product.price}</td>
            <td>{this.props.product.location}</td>
            <td>
                <button type="button" class="btn btn-danger" onClick={this.deleteProductById}>DELETE</button>

            </td>
          
          </tr>
          
          );
    }
}

export default connect()(ProductRow);
