import React, { Component } from 'react';

class Greet extends Component {



    render() {
      var {fname,lname}=this.props;

      
      console.log(this.props);
        console.log("=============================================");
        return (

            <div>
                          {this.props}
                <h2>  Greeting to {fname}   {lname}   </h2>
            
            
            </div>
        );
    }
}

export default Greet;