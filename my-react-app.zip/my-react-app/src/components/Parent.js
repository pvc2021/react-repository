import React, { Component } from 'react';
import Child from './Child'
class Parent extends Component {


state={
    message:'Hello Child',
    childMessage:''
}



getChildMessage=(childMessage)=>{
console.log("Parent Getting Message From Child");
this.setState({childMessage:childMessage})
}




    render() {

        let {message,childMessage}=this.state;
        return (
            <div class="jumbotron">
               <font size="4"   color="blue">

            <h2>Passing the event handler as props to Child Component</h2> 


                  Child Message :{childMessage} 
                   
                                    
        </font> 
        <Child     childChanged={this.getChildMessage}        parentMessage={message}/>
  
        
            </div>
        );
    }
}

export default Parent;