import React, { Component } from 'react';
import Greet from "./Greet"
import Colors from "./Colors"

class ReactBasics extends Component {

    
    render() {

        let colors=["RED","GREEN","BLUE"];
        let fname="Sachin";
        let lname="Chinchole";

        return (
            <div>
               <h2> React Basics Component </h2>
               <Greet/>
               <hr/>
               <Greet fname="Sachin"/>
               <hr/>
               <Greet fname={fname}  lname={lname}  {...colors}/>
                


<Colors    name="Mohan"/>
            </div>
        );
    }
}

export default ReactBasics;