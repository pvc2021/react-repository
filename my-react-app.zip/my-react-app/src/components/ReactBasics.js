import React, { Component } from 'react';
import Greet from "./Greet"
import Colors from "./Colors"
import ErrorBoundry from "./ErrorBoundry"
class ReactBasics extends Component {

    
    render() {

        let colors=["RED","GREEN","BLUE"];
        let fname="Sachin";
        let lname="Chinchole";

        return (
            <ErrorBoundry>    
             
            <div>
               <h2> React Basics Component </h2>
               
              
                             
            <Greet/>
            
               <hr/>
               <Greet fname="Sachin"/>
               <hr/>
               <Greet fname={fname}  lname={lname}  {...colors}/>
            

                   <Colors    name="Mohan"/>


            </div>
            </ErrorBoundry> 

        );
    }
}

export default ReactBasics;