import axios from 'axios';
import React, { Component } from 'react';
import {connect} from 'react-redux';



class AddProduct extends Component {


    constructor(props){
        super(props);
        this.state={
            id:'',
            name:'',
            price:'',
            location:''
        }
    }


    handleIdChange=(event)=>{
        this.setState({id:event.target.value})
    }

    handleNameChange=(event)=>{
        this.setState({name:event.target.value})
    }

    handlePriceChange=(event)=>{
        this.setState({price:event.target.value})
    }

    handleLocationChange=(event)=>{
        this.setState({location:event.target.value})
    }


    addProduct=(event)=>{
        event.preventDefault();
        let data={
            "id":this.state.id,
            "name":this.state.name,
            "price":this.state.price,
            "location":this.state.location
        }


        axios.post("http://localhost:3001/products",data)
        .then(response=>{
            if(response.status===201){
              this.refs.addProductForm.reset();
              this.props.dispatch({
                type:'ADD_PRODUCT',
                product:response.data
            })
        }}).catch(error=>{
            console.log(error);
        })






    }



    render() {
        return (
            <form  onSubmit={this.addProduct}  ref="addProductForm">

            <div className="form-group">
            <label>Product Id :</label>
            <input type="text"  name="id"   onChange={this.handleIdChange}/>
            </div>
            
            <div className="form-group">
            <label>Product Name :</label>
            <input type="text"  name="name"   onChange={this.handleNameChange}/>
            </div>
            
            <div className="form-group">
            <label>Product Price :</label>
            <input type="text"  name="price"   onChange={this.handlePriceChange}/>
            </div>

            <div className="form-group">
            <label>Location :</label>
            <input type="text"  name="location"   onChange={this.handleLocationChange}/>
            </div>

            
            <input type="submit"  className="btn btn-primary"   value="Add Product"/>
             </form>
             );
    }
}

export default   connect()(AddProduct);