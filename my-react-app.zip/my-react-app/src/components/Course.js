import React, { Component } from 'react';

class Course extends Component {
   

constructor(props){
    super(props);
   this.state={
       courseId:101,
       courseName:'React',
       coursePrice:12000
   }
}

//generic function
handleInputchange=(e)=>{
    this.setState({
        [e.target.name]:e.target.value
    })
}

handleCourseIdChange=(e)=>{
    this.setState({
        courseId:e.target.value
    })
}


handleCourseNameChange=(e)=>{
    this.setState({
        courseName:e.target.value
    })
}


handleCoursePriceChange=(e)=>{
    this.setState({
        coursePrice:e.target.value
    })
}

handleSubmit=(e)=>{
    alert('Your course details:'+this.state.courseId+"   "+this.state.courseName+"   "+this.state.coursePrice);
}





    render() {
        return (
            <div>
                <h3> Course Form (Uncontrolled Form)</h3>
                
                
 <form  onSubmit={this.handleSubmit}>

<div className="form-group">
<label>Course Id :</label>
<input type="text"  value={this.state.courseId} name="courseId"   onChange={this.handleInputchange}/>
</div>

<div className="form-group">
<label>Course Name :</label>
<input type="text"  value={this.state.courseName} name="courseName"   onChange={this.handleInputchange}/>
</div>

<div className="form-group">
<label>Course Price :</label>
<input type="text"  value={this.state.coursePrice} name="coursePrice"   onChange={this.handleInputchange}/>
</div>

<input type="submit"  className="btn btn-primary"   value="Submit"/>
 </form>
<hr/>

<pre>
Course Id     :{this.state.courseId} <br/>
Course Name   :{this.state.courseName} <br/>
Course Price  :{this.state.coursePrice} <br/>
</pre>

</div>
        );
    }

}

export default Course;