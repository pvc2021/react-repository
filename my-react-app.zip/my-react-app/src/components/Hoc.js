import React, { Component } from 'react'
import HoverCounter from './HoverCounter'
import ClickCounter from './ClickCounter'


export default class Hoc extends Component {
  render() {
    return (
      <div>
         <h2>React Forms</h2>
           <HoverCounter/>
           <hr/>
           <ClickCounter/>
           
      </div>
    )
  }
}
