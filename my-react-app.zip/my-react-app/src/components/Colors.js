import React, { Component } from 'react';

function Colors(props) {


    let colors=["RED","GREEN","BLUE"];


    console.log("==================");
    console.log(props);
    

    return (<div style={{backgroundColor: "lightgreen"}}>
        <h3  style={{color: "green"}}>My Favourate Colors </h3>
                  <ul>
                      {colors.map(c=>{
                          return <li>{c}</li>
                      })}
                  </ul>

            </div>)

}

export default Colors;