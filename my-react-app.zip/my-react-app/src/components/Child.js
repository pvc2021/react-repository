import React, { Component } from 'react';

class Child extends Component {



    state={
        message:'Hi Parent'
    }

    render() {

     let {message} =this.state;
     let {childChanged}=this.props;


        return (
            <div class="jumbotron">
                <font size="4" color="green">
                   Parent Message :{this.props.parentMessage}
                    
                   <h2>  Child Message : {message}</h2>
                   Enter Message To Send to Parent    

                <input ref={input=>this.message=input}    onChange={()=>childChanged(this.message)} />

          <br/><br/>


            <button class="btn btn-info" onClick={()=>childChanged(message+"  "+Math.random()*10)}>Send Message To Parent</button>
                </font>

           

            </div>
        );
    }
}

export default Child;