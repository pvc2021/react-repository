import React, { Component } from 'react';
import './Catalog.css';

class Catalog extends Component {


    constructor(props) {
        super(props)

        this.state = {
            technologies: [
                { id: 1, name: 'Spring Boot', likes: 0, dislikes: 0 },
                { id: 2, name: 'Angular', likes: 0, dislikes: 0 },
                { id: 3, name: 'React', likes: 0, dislikes: 0 },
                { id: 4, name: 'Micro Services', likes: 0, dislikes: 0 },
                { id: 5, name: 'Docker', likes: 0, dislikes: 0 }
            ]
        };
        console.log("===========Catlog Component created============");
    }



    componentDidMount() {
        console.log("===========Catlog Component DidMount============");
    }

    componentWillUnmount() {
        console.log("===========Catlog Component WiilUnMount============");
    }


    componentDidUpdate() {
        console.log("===========Catlog Component DidUpdate============");
    }




    render() {





        
        return (
            <div class="jumbotron">

                       


                <h2>Top 5 Technologies </h2>
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>LIKES</th>
                            <th>DISLIKES</th>
                            <th>LIKE IT</th>
                            <th>DISLIKE IT</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.technologies.map(t=>{
                           return <tr key={t.id}>
                              <td>{t.id}</td>
                              <td>{t.name}</td>
                              <td>{t.likes}</td>
                              <td>{t.dislikes}</td>
                              <td> <input type="button" value="LIKE IT" class="btn btn-success" />  </td>
                              <td> <input type="button" value="DISLIKE IT" class="btn btn-danger" />  </td>
                          </tr>
                          })


                    }
                   </tbody>
                </table>



            </div>
        );
    }
}

export default Catalog;