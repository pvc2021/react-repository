import axios from 'axios';
import React, { Component } from 'react';
import {Link} from "react-router-dom"

class UsersList extends Component {
    state={
        title:'Users List',
        users:[]
      }
    
    constructor(props){
        super(props);
        console.log("=============UsersList creeated================");
    }
    
    
    componentDidMount(){
    console.log("===Getting the posts from  :https://jsonplaceholder.typicode.com/users====");
    axios.get('https://jsonplaceholder.typicode.com/users')
         .then(response=>{
             this.setState({users:response.data})
         }) 
    }
    
    
    componentWillUnmount(){
        console.log("=============PostComponent destroyed================");  
    }
    
    
    
    
        render() {

            let {users}=this.state;

            console.log("In render :"+users);

            return (
                <div class="jumbotron">
                    
                    <h2>  {this.state.title} </h2>
    
                   <div class="list-group">
                    {
                    users.map(user=>{
                 return <a   key={user.id} class="list-group-item">  <Link to={`/user/${user.id}`}> {user.username}</Link>   </a>       
                    })

                    }



                   </div>
    
                     
               
    
                </div>
            );
        }
}

export default UsersList;