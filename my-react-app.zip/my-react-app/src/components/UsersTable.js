import axios from 'axios';
import React, { Component } from 'react';
import {Link} from "react-router-dom"

class UsersTable extends Component {
    state={
        title:'Users Table',
        users:[]
      }
    
    constructor(props){
        super(props);
        console.log("=============UsersList creeated================");
    }
    
    
    componentDidMount(){
    console.log("===Getting the posts from  :https://jsonplaceholder.typicode.com/users====");
    axios.get('https://jsonplaceholder.typicode.com/users')
         .then(response=>{
             this.setState({users:response.data})
         }) 
    }
    
    
    componentWillUnmount(){
        console.log("=============PostComponent destroyed================");  
    }
    
    
    
    
        render() {
            return (
                <div class="jumbotron">
    
                           
    
    
                    <h2>  {this.state.title} </h2>
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>USER ID</th>
                                <th>USER NAME</th>
                                <th>EMAIL</th>
                                <th>CITY</th>
                                <th>COMPANY</th>
                                
                                <th>VIEW POSTS</th>
                                <th>VIEW TODOS</th>
                                <th>VIEW ALBUMS</th>


                              </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.users.map(u=>{
                               return <tr key={u.id}>
                                  <td>{u.id}</td>
                                  <td>{u.name}</td>
                                  <td>{u.email}</td>
                                  <td>{u.address.city}</td>
                                  <td>{u.company.name}</td>
                                  
                                  <td> <Link to={`/posts?userId=${u.id}`}> <input type="button" value="VIEW POSTS" class="btn btn-info" />  </Link></td>
                                  <td><Link to={`/todos?userId=${u.id}`}> <input type="button" value="VIEW TODOS" class="btn btn-primary" /> </Link> </td>
                                  <td><Link to={`/albums?userId=${u.id}`}> <input type="button" value="VIEW ALBUMS" class="btn btn-success" /> </Link> </td>
                                                         
                              </tr>
                              })
    
    
                        }
                       </tbody>
                    </table>
    
    
    
                </div>
            );
        }
}

export default UsersTable;