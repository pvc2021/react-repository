import  {createStore} from 'redux';


import { rootReducer } from '../reducers/rootReducer';

let productStore=createStore(rootReducer);

export default productStore;