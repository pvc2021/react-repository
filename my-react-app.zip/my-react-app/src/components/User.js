import axios from 'axios';
import React, { Component } from 'react';
import {Link} from "react-router-dom"

class User extends Component {
    
    
    constructor(props){
        super(props);
        this.state={
            userId:this.props.match.params.userId,
            user:{
                "id": 12222,
                "name": "Leanne Graham",
                "username": "Bret",
                "email": "Sincere@april.biz",
                "address": {
                  "street": "Kulas Light",
                  "suite": "Apt. 556",
                  "city": "Gwenborough",
                  "zipcode": "92998-3874",
                  "geo": {
                    "lat": "-37.3159",
                    "lng": "81.1496"
                  }
                },
                "phone": "1-770-736-8031 x56442",
                "website": "hildegard.org",
                "company": {
                  "name": "Romaguera-Crona",
                  "catchPhrase": "Multi-layered client-server neural-net",
                  "bs": "harness real-time e-markets"
                }
              }
          }
        console.log("=============User creeated================");
    }
    
    
    componentDidMount(){
    console.log("===Getting the posts from  :https://jsonplaceholder.typicode.com/users====");
    
    axios.get(`https://jsonplaceholder.typicode.com/users/${this.state.userId}`)
         .then(response=>{
             this.setState({user:response.data})
         }) 
    }
    
    
    componentWillUnmount(){
        console.log("=============User destroyed================");  
    }
    
    
    
    
        render() {



            let {user} =this.state;
            return (
                <div class="jumbotron">
                    
                    <h2>  {this.state.user.name} Details </h2>
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>USER ID</th>
                                <th>USER NAME</th>
                                <th>EMAIL</th>
                                <th>CITY</th>
                                <th>COMPANY</th>
                                
                                <th>VIEW POSTS</th>
                                <th>VIEW TODOS</th>
                                <th>VIEW ALBUMS</th>


                              </tr>
                        </thead>
                        <tbody>
                                                
                               <tr>
                                  <td>{this.state.user.id}</td>
                                  <td>{this.state.user.name}</td>
                                  <td>{this.state.user.email}</td>
                                  <td>{this.state.user.address.city}</td>
                                  <td>{this.state.user.company.name}</td>
                                  
                                  <td> <Link to={`/posts?userId=${this.state.user.id}`}> <input type="button" value="VIEW POSTS" class="btn btn-info" />  </Link></td>
                                  <td><Link to={`/todos?userId=${this.state.user.id}`}> <input type="button" value="VIEW TODOS" class="btn btn-primary" /> </Link> </td>
                                  <td><Link to={`/albums?userId=${this.state.user.id}`}> <input type="button" value="VIEW ALBUMS" class="btn btn-success" /> </Link> </td>
                                                         
                              </tr>
                            
    
    
                    
                       </tbody>
                    </table>
    
               
    
                </div>
            );
        }
}

export default User;