import React, { Component } from 'react';

import Parent from "./Parent"
import Child from "./Child"

class StateLift extends Component {

    
    render() {

         return (
            <div>
               <h2> React State Lift Demo </h2>
               
                <Parent/>
                <hr/>
               
      
               

            </div>
        );
    }
}

export default StateLift;