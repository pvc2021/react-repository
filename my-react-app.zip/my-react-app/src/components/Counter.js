import React, { Component, PureComponent } from 'react';

class Counter extends PureComponent {

    state={
        count:0
    }


constructor(props){
    super(props);

//Syntax1 -Event binding
//this.incrementHandler=this.incrementHandler.bind(this);
console.log("============Counter Component created=========="+this.state.count);
  
}



  /*
   incrementHandler(){
       console.log("incrementing count :"+this.state.count);
       //this.state.count=this.state.count+1;

       this.setState((prevState)=>{
            return {count:prevState.count+1}
       })
   }
*/



incrementHandler=()=>{
    this.setState((prevState)=>{
        return {count:prevState.count+1}
   });
}


    render() {

        const mystyle = {
            color: "white",
            backgroundColor: "DodgerBlue",
            padding: "10px",
            fontFamily: "Arial"
          };

        console.log("==========Called render==========");
        return (
            <div  style={mystyle}>
                <h2> Counter Demo</h2>
                <hr/>
                <h2>  Count  :  {this.state.count}</h2>
            <input type="button"   onClick={this.incrementHandler}  value="Increment Count" class="btn btn-info"/>
                        
            <input type="button"   onClick={()=>this.incrementHandler()}  value="Increment Count" class="btn btn-primary"/>
            
            </div>
        );
    }

    componentDidMount(){
        console.log("============Counter Component Did Mount=========="+this.state.count);
    }


    componentWillUnmount(){
        console.log("============Counter Component Will UnMount=========="+this.state.count);
        
    }



}

export default Counter;