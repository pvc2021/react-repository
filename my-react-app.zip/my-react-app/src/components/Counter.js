import React, { Component } from 'react';

class Counter extends Component {

    state={
        count:0
    }


constructor(props){
    super(props);

//Syntax1 -Event binding
//this.incrementHandler=this.incrementHandler.bind(this);
}



  /*
   incrementHandler(){
       console.log("incrementing count :"+this.state.count);
       //this.state.count=this.state.count+1;

       this.setState((prevState)=>{
            return {count:prevState.count+1}
       })
   }
*/

incrementHandler=()=>{
    this.setState((prevState)=>{
        return {count:prevState.count+1}
   });
}


    render() {
        return (
            <div>
                <h2> Counter Demo</h2>
                <hr/>
                <h2>  Count  :  {this.state.count}</h2>
            <input type="button"   onClick={this.incrementHandler}  value="Increment Count" class="btn btn-info"/>
                        
            <input type="button"   onClick={()=>this.incrementHandler()}  value="Increment Count" class="btn btn-primary"/>
            
            </div>
        );
    }







}

export default Counter;