import axios from 'axios';
import React, { Component as C } from 'react';
import ProductRow from "./ProductRow";
import {connect} from 'react-redux';


class ListProducts extends C {



    constructor(props){
        super(props);
        console.log("=========ListProductComponet created===========");
    }



    componentDidMount(){

      console.log("==========ListProducts component mounted==========");
       axios.get("http://localhost:3001/products")
             .then(response=>{
                 this.props.dispatch({
                     type:'FETCH_PRODUCT',
                     products:response.data
                 })
             }).catch(error=>{
                 console.log(error);
             })



    }




    render() {
        console.log("In render "+this.props);
        return (
            <div>
                <table class="table table-striped table-bordered table-hover">

                 <thead>
                <tr>
                <th>PRODUCT ID</th>
                <th>PRODUCT NAME</th>
                <th>PRODUCT PRICE</th>
                <th>LOCATION</th>
                </tr>     
                </thead>   

<tbody>
     {
this.props.products.productReducer.map((product,index)=>
<ProductRow   product={product} key={index}/>
)

     }




</tbody>




                </table>
                
            </div>
        );
    }
}


const mapStateToProps=(state)=>{
    return {
        products:state
    }
}

export default connect(mapStateToProps)(ListProducts);